import boto3
import sys
import time

ec2_client = boto3.client('ec2')
asg_client = boto3.client('autoscaling')
r53_client = boto3.client('route53')

domain = "myinternaldns.com."
ttl = 60

def get_hosted_zone_id(domain):
    for hosted_zone in r53_client.list_hosted_zones()['HostedZones']:
        if hosted_zone['Name'] == domain:
            print(hosted_zone)
            return hosted_zone['Id']

def get_asg_private_ips(asg_name):
    for asg in asg_client.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])['AutoScalingGroups']:
        instance_ids = []
        test = {}
        for instance in asg['Instances']:
            if instance['LifecycleState'] == 'InService':
                instance_ids.append(instance['InstanceId'])
                for reservation in ec2_client.describe_instances(InstanceIds = [instance['InstanceId']])['Reservations']:
                    for instance in reservation['Instances']:
                        if instance['State']['Name'] == 'running':
                            test[instance['InstanceId']] = instance['PrivateIpAddress']
    return test

def update_hosted_zone_records(hosted_zone_id, ttl, server,instance_id):
    server_dict = {}
    server_dict["Value"] = server
    record_set_name = instance_id + "." + domain
    r53_client.change_resource_record_sets(
    HostedZoneId = hosted_zone_id,
    ChangeBatch = {
        'Changes': [
            {
            'Action': 'UPSERT',
            'ResourceRecordSet': {
                'Name': record_set_name,
                'Type': 'A',
                'TTL': ttl,
                'ResourceRecords': [server_dict]
            }
        }]
    })
    return

def deleted_hosted_zone_records(hosted_zone_id,instance_id):
    list_records = r53_client.list_resource_record_sets(
        HostedZoneId=hosted_zone_id,
        )
    for record in list_records["ResourceRecordSets"]:
        print(record['Name'][:19], instance_id)
        if type(record) == dict and instance_id == record['Name'][:19]:
            server = record["ResourceRecords"]

    record_set_name = instance_id + "." + domain
    r53_client.change_resource_record_sets(
    HostedZoneId = hosted_zone_id,
    ChangeBatch = {
        'Changes': [
            {
            'Action': 'DELETE',
            'ResourceRecordSet': {
                'Name': record_set_name,
                'Type': 'A',
                'TTL': ttl,
                'ResourceRecords': server
            }
        }]
    })
    return

def lambda_handler(event, context):
    asg_name = event['detail']['AutoScalingGroupName']
    hosted_zone_id = get_hosted_zone_id(domain)
    records = get_asg_private_ips(asg_name)
    if event['detail']['Description'][:4] == "Term":
        deleted_hosted_zone_records(hosted_zone_id, event['detail']['Description'][-19:])
        print(f"Delete {event['detail']['Description'][-19:]} with A record")
    elif event['detail']['Description'][:6] == "Launch":
        server = records[event['detail']['Description'][-19:]]
        records[event['detail']['Description'][-19:]]
        update_hosted_zone_records(hosted_zone_id, ttl, server, event['detail']['Description'][-19:])
        print(f"ADD {event['detail']['Description'][-19:]} with A record {server}")
    else:
        print("nothing todo")
