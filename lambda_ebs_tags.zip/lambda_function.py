import json
import boto3

ec2_resource = boto3.resource('ec2')
ec2_client = boto3.client('ec2')

def lambda_handler(event, context):
    ebs = ec2_client.describe_volumes()
    ec2 = ec2_client.describe_instances()
    for instance in ec2["Reservations"]:
        for volume in ebs["Volumes"]:
            list_of_bd = instance["Instances"][0]["BlockDeviceMappings"]
            if list_of_bd != [] and list_of_bd[0]["Ebs"]["VolumeId"] == volume["VolumeId"]:
                id_volume = volume["VolumeId"]
                if instance["Instances"][0]["Tags"] != volume["Tags"]:
                    volume = ec2_resource.Volume(volume["VolumeId"])
                    tags = instance["Instances"][0]["Tags"]
                    list_keys = []
                    for tag in tags:
                        tags_modify = {}
                        for key, value in tag.items():
                            if value[:3] == "aws":
                                tags_modify[key] = "replacement"
                            else:
                                tags_modify[key] = value
                        list_keys.append(tags_modify)
                    volume.create_tags(
                        Tags = list_keys,
                        )
                    print(f'Change tags at {id_volume}')